import pandas as pd
from datetime import datetime as dt

# Format today's date for API Call
now = dt.isoformat(dt.now())

# Set the data interval in minutes, start date, end date, apikey, and create a list of symbols to download
interval = 1 # interval in minutes  
start = 20171130000000 # start date for your dataset, which I have set as the day when the March Contract became the front month
end = now[0:4]+now[5:7]+now[8:10]+'000000' # end date for your dataset
apikey = "your_api_key_here" # replace everything between the quotes with your api key 
symbols = ['ZTH18','ZFH18','ZNH18','ZBH18'] # your list of symbols
dfs = {} # Create empty dictionary for storing your data

# Loop through symbol list and store as a dictionary of Data Frame's
for s in symbols:
    dfs[s] = pd.read_csv('https://marketdata.websol.barchart.com/getHistory.csv?apikey={}&symbol={}&startDate={}&endDate={}&type=minutes&interval={}&volume=contract'.format(apikey,s,start,end,interval))
    print ('symbol{}'.format(s) + 'loaded')

 df = pd.concat([dfs['ZTH18'],dfs['ZFH18'],dfs['ZNH18'],dfs['ZBH18']])

# Convert to datetime object
df.index = pd.to_datetime(df.timestamp)

# Standardize the time zone according to UTC 
df.index = df.index.tz_localize('UTC')

# Convert to local time zone
df.index = df.index.tz_convert('US/Central')

# Drop the old timestamp column
df = df.drop('timestamp', axis = 1)

# Create a Data Frame for each trading session 
europe = df.between_time('0:00', '7:20', include_start=True, include_end=False)
us = df.between_time('7:20', '16:00', include_start=True, include_end=False)
asia = df.between_time('16:00', '23:59', include_start=True, include_end=True)

# Concatenate the dataset row-wise (axis=0), aka append vertically
comb = pd.concat([asia,europe,us],keys=['asia','europe','us'])

# Reset the index and rename the session column
comb = comb.reset_index()
comb = comb.rename(columns = {'level_0':'session'})

# Create Hour and Minute column
comb['hour'] = comb.timestamp.apply(lambda x: x.hour)
comb['day'] = comb.timestamp.apply(lambda x: x.day)
comb['week'] = comb.timestamp.apply(lambda x: x.week)
comb['date'] = comb.timestamp.apply(lambda x: x.date())

# Write the raw data to csv
comb.to_csv('1_minute_treasury_futures.csv')

# Create OHLC bars for each trading session
# ohlc = comb.groupby(['symbol','date','session']).agg(
#     {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume':'sum'})





























